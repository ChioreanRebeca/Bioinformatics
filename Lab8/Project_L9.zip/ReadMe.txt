Lita Naomi
Chiorean Rebeca