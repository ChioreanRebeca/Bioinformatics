Team:
Liță Naomi
Chiorean Rebeca